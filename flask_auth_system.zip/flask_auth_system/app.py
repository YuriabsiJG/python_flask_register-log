from flask import Flask, render_template
from db import init_db
from routes.auth import auth_bp
import time

app = Flask(__name__)
init_db(app)

app.register_blueprint(auth_bp, url_prefix="/auth")

# Add this route to serve the homepage
@app.route("/")
def home():
    return render_template("index.html", time=int(time.time()))  # Forces a new version

if __name__ == "__main__":
    app.run(debug=True)
