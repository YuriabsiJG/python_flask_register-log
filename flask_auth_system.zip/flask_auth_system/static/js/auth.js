// Register User
async function registerUser() {
    let response = await fetch("/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: document.getElementById("register-username").value,
            email: document.getElementById("register-email").value,
            password: document.getElementById("register-password").value
        })
    });
    let data = await response.json();
    alert(data.message);
}

// Login User
async function loginUser() {
    let response = await fetch("/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: document.getElementById("login-email").value,
            password: document.getElementById("login-password").value
        })
    });
    let data = await response.json();
    if (response.ok) {
        alert("Login Successful");
    } else {
        alert("Invalid Credentials");
    }
}
