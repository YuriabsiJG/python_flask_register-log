class Config:
    SECRET_KEY = "your_secret_key"
    MYSQL_HOST = "localhost"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "password@1234"
    MYSQL_DB = "auth_db"
