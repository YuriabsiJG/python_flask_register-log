from db import mysql
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()

class User:
    @staticmethod
    def register(username, email, password):
        cur = mysql.connection.cursor()
        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        cur.execute("INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)", (username, email, hashed_pw))
        mysql.connection.commit()
        cur.close()

    @staticmethod
    def login(email, password):
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, password_hash FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close()
        if user and bcrypt.check_password_hash(user[1], password):
            return user[0]  # Return user ID if password matches
        return None
