from flask import Blueprint, request, jsonify
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3  # Use MySQL or PostgreSQL if needed

auth_bp = Blueprint('auth', __name__)

# Database Connection Function
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",  # Change this
            password="password@1234",  # Change this
            database="auth_db"  # Your database name
        )
        return conn
    except Exception as e:
        print(f"Database connection failed: {str(e)}")  # Debugging
        return None

# User Registration Route with Error Handling
@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')

        if not username or not email or not password:
            return jsonify({"error": "All fields are required!"}), 400

        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        if conn is None:
            print("❌ Database connection failed!")  # Debugging
            return jsonify({"error": "Database connection failed!"}), 500

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            return jsonify({"error": "Email is already registered!"}), 409

        cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                       (username, email, hashed_password))
        conn.commit()
        conn.close()

        return jsonify({"message": "User registered successfully!"}), 201

    except Exception as e:
        print(f"❌ Registration error: {str(e)}")  # Print full error
        return jsonify({"error": f"Registration failed: {str(e)}"}), 500


# User Login Route with Error Handling
@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({"error": "Email and Password are required!"}), 400

        conn = get_db_connection()
        if conn is None:
            print("❌ Database connection failed!")  # Debugging
            return jsonify({"error": "Database connection failed!"}), 500

        cursor = conn.cursor(dictionary=True)  # Ensure dictionary cursor
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()

        if user is None:
            print("❌ No user found with that email!")  # Debugging
            return jsonify({"error": "Invalid email or password!"}), 401

        print(f"🔍 Found user: {user}")  # Debugging

        if not check_password_hash(user["password"], password):
            print("❌ Password did not match!")  # Debugging
            return jsonify({"error": "Invalid email or password!"}), 401

        return jsonify({"message": "Login successful!"}), 200

    except Exception as e:
        print(f"❌ Login error: {str(e)}")  # Print full error
        return jsonify({"error": f"Login failed: {str(e)}"}), 500
